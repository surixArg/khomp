# Kiper Access Veicular
### Version 1.0.13 Update 28
1 de febrero de 2024
Commit 23f4ddc5be1ab6fa84976b26a3a9d37824935cbe
---
### Changelog
* [Trello](https://trello.com/c/kWyjhBaB/443-access-veicular-bugfix-menu-licenciamento). El menú "Licenciamento" es ahora exclusivo para usuarios root.
* [Trello](https://trello.com/c/kTRbyMAu/447-access-veicular-n%C3%A3o-est%C3%A1-retornando-o-n%C3%BAmero-da-vers%C3%A3o-do-access-veicular-no-log). Se agregó un log con el número de versión al iniciar el sistema.
* [Trello](https://trello.com/c/DaJbETpy/284-access-veicular-acesso-a-interface-web). Se permite iniciar sesión en la web sin antes hacer logout en una sesión previa. La sesión anterior finaliza automáticamente sin necesidad de esperar al timeout.
* [Trello](https://trello.com/c/xgiu5hXv/452-access-veicular-bug-no-controle-de-acesso-por-hor%C3%A1rio). Se arregla el control de acceso por horarios. Se añadieron verificaciones, de forma tal que, si el comando contiene horarios mal formados, no serán aceptados. Ejemplos: "24:35", "12:", ":18", "23:79", ":". Se soluciona un bug que provocaba que se generen más horarios de los pedidos por el mensaje MQTT. Los usuarios se muestran correctamente con sus horarios por día al acceder a /?users.
* [Trello](https://trello.com/c/GuuPxG2O/453-access-veiular-n%C3%A3o-gera-ack-fail-quando-rfid-maior-que-15-digitos). Se añade verificación para el ID de cada control. Ahora, si un usuario tiene un control con un ID que no es aceptado, el usuario será creado ignorando ese control. En caso de que haya solo un control en el mensaje MQTT, y que ese ID no sea aceptado, fallará el registro del usuario.
* [Trello](https://trello.com/c/dVjrqPNn/445-access-veicular-n%C3%A3o-est%C3%A1-gerando-reset-reason). Se agrega, nuevamente, el Reset Reason al log.
