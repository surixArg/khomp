# Kiper Access Veicular
### Version 1.0.13 Update 29
5 de febrero de 2024
Commit bbe9c78555bdb93dcb965ec881344af400269740
---
### Changelog
* [Trello](https://trello.com/c/nULQItFu/276-access-veicular-feature-integra%C3%A7%C3%A3o-com-o-produto-veicular-ble). Se implementó el checksum para la comunicación entre Access Veicular y Access BLE.
* [Trello](https://trello.com/c/LqUQgweg/454-access-veicular-feature-apagar-filesystem-por-comando-mqtt). Se implementó el comando clean_fs, el cual, via MQTT, permite limpiar el filesystem del Access Veicular, sin perder la configuración del mismo. Uso: {"cmd": "clean_fs", ... }
---
Por favor, probar estas nuevas funcionalidades e informar sobre su funcionamiento. Quedamos a su disposición, SURiX Ingeniería.
