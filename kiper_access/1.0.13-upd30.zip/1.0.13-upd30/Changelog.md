# Kiper Access Veicular
### Version 1.0.13 Update 30
6 de febrero de 2024
Commit ace8d49abe451ee315f29a9f423cbd1c1120141e 

---

### Changelog
* Se aumentó la cantidad máxima de bits para los identificadores de los controles RFID a 28 bits (antes era 24 bits). Por lo tanto, el máximo ID posible es 2^28 - 1, es decir, 268435455.

---
