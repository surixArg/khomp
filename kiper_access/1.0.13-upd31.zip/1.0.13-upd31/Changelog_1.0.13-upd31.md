# Kiper Access Veicular

### Version 1.0.13 Update 31

7 de febrero de 2024
Commit 31ac142988e1441399313e8cea022e4b507b712a

---

### Changelog
* [Trello](https://trello.com/c/nULQItFu/276-access-veicular-feature-integra%C3%A7%C3%A3o-com-o-produto-veicular-ble). No se espera ID en los mensajes de broadcast de BLE.

##### [Trello](https://trello.com/c/CnBEGzo1/450-access-veicular-instabili10-nas-vers%C3%B5es-atuais-tamb%C3%A9m). Mejoras de estabilidad:
* Se agrega reinicio por falla en la conexión MQTT. Esto debiera mejorar la estabilidad de conexión de la placa.
* Se agrega reintento de ping en 3.
---
