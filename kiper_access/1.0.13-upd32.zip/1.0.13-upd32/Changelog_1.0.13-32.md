# Kiper Access Veicular
### Versión 1.0.13 Update 32
8 de febrero de 2024
Commit ef85f7736789cce2a32d0aa045d34bddb93fc439
---
### Changelog:
* Se agregó un watchdog de memoria.
* Se agregan logs en la inicialización de BLE.
