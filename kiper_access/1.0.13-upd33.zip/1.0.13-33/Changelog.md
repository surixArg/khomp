# Kiper Access Veicular
### Version 1.0.13 Update 33
14 de febrero de 2024
Commit 52bc132b1bf108dcee93304d944526dee43a2b85
---
### Changelog
* [FIX] Se solucionó un memory leak encontrado.
