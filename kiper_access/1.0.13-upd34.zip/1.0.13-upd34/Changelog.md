# Kiper Access Veicular
### Version 1.0.13 Update 34
15 de febrero de 2024
Commit 7e707fcc96348e184a6949a9f867e40377871d3b
---
### Changelog
* [Trello](https://trello.com/c/GeNJMawd/455-access-veicular-clean-fs-por-interface-web-tamb%C3%A9m-somente-pra-usu%C3%A1rio-root). Se agrega botón de Clean FS al menú Actions.
* Mejoras de estabilidad en logs y file system.
