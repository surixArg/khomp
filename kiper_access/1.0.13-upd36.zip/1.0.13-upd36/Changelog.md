# Kiper Access Veicular

### Version 1.0.13 Update 36

20 de febrero de 2024
Commit fe81df0b9cdbd5655470ff207fe817f81681b5b0

---

### Changelog

En esta versión estamos probando una solución al problema
que generaba un reinicio al utilizar el comando set_gw_info.
Pedimos por favor que prueben el correcto funcionamiento del
comando y que nos informen de cualquier problema que noten.
**En esta versión, de manera temporal, está desactivada la
feature que guarda los logs en el archivo kLog.txt**. Esta
modificación es temporal y se hizo a propósito para realizar
las mencionadas pruebas.
