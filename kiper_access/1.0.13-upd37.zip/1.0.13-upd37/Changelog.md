# Kiper Access Veicular
### Version 1.0.13 Update 37
Compilation date: 2024/02/20
Commit: acfa92f3b85fc32f64afaabed826344e541c6239
---
### Changelog
Este update debiera solucionar el problema original de restablecimiento a fábrica tras
un comando "set_gw_info" de forma definitiva. Se volvió a habilitar el guardado de logs
en el archivo kLog.txt.
