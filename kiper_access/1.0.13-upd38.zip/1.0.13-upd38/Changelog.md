# Kiper Access Veicular
### Version 1.0.13 Update 38
Compilation date: 2024/03/06
Commit: a7cf386c0f7fefef10aa5b187e6f48fb79cdeb6a
---
### Changelog
* [Trello](https://trello.com/c/w4TmdK5p/460-access-veicular-bugfix-userid-no-doorrideaccessed-vindo-como-null). Esta versión debería solucionar el bug de "user_id": null en "door_ride_accessed". Por favor, verificar e informar sobre el estado del bug a la brevedad.
* Se soluciona un error de seguridad que causaba que los usuarios puedan acceder a las 00:00 de cualquier día en el que tuvieran acceso en algún rango horario, incluso si no tenían acceso a las 00:00.
* Se mejora la estabilidad del control de acceso. Es posible que ocurran falsos positivos o falsos negativos, que están relacionados con el reloj interno del sistema y no con el control de acceso. Los mismos serán resueltos próximamente.
