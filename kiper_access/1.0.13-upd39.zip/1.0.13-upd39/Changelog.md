# Kiper Access Veicular
### Version 1.0.13 Update 39
Compilation date: 2024/03/06
Commit: 4425bdda387b545a302d0bb95ca1ca27197ac94c
---
### Changelog
* Esta versión agrega un syslog que muestra el horario y los intervalos de acceso al rechazar un acceso por reason -60. Este cambio ayudará a debuggear y resolver problemas con el control de horario. Por favor, realizar pruebas de acceso con esta versión.
