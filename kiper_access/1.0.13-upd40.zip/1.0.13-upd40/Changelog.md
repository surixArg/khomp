# Kiper Access Veicular
### Version 1.0.13 Update 40
Compilation date: 2024/03/07
Commit: 61921d1c2a7ab21bcd1411965782739aa127bf13
---
### Changelog
* [Trello](https://trello.com/c/w4TmdK5p/460-access-veicular-bugfix-userid-no-doorrideaccessed-vindo-como-null). Se soluciona el user_id null en door_ride_access.
* [Trello](https://trello.com/c/xgiu5hXv/452-access-veicular-bug-no-controle-de-acesso-por-hor%C3%A1rio). Se soluciona el corrimiento de horario al enviar un control.

