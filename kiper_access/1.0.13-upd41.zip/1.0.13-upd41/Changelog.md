# Kiper Access Veicular
### Version 1.0.13 Update 41
Compilation date: 2024/03/08
Commit: 75658bd1da77e0892b793a46db1cddb83c7706ff
---
### Changelog
* [Trello](https://trello.com/c/MmkXC9St/468-access-veicular-bugfix-lista-de-eventos-offline). Se soluciona el bug que mostraba los eventos offline de tipo "send_access_code_rf" con todos sus parámetros en cero. Los eventos offline están funcionando correctamente en esta versión, en nuestras pruebas. Por favor probar esta feature con una instalación limpia de firmware e informar los resultados.
