# Kiper Access Veicular
### Version 1.0.13 Update 42
Compilation date: 2024/03/11
Commit: 53d4ef83eedebf144565a204bdba7002499742ea
---
### Changelog
* [Trello](https://trello.com/c/w4TmdK5p/460-access-veicular-bugfix-userid-no-doorrideaccessed-vindo-como-null). En esta nueva versión, debiera resolverse el user_id en door_ride accessed.
