# Kiper Access Veicular

### Version 1.0.13 Update 43

Compilation date: 2024/03/13
Commit: 4f962a116b0cccdeb095770b16e4c1d30ea0e011

---

### Changelog

Los siguientes problemas fueron solucionados, sin embargo, es necesario testear el funcionamiento. Por favor testear e informar:
* Se soluciona un problema que causaba que el CRC fallara en ciertas comunicaciones con la placa YET233-B.
* Se soluciona un problema en el cual algunos controles podían no ser reconocidos si antes se recibía un control con el mismo contador, aunque el ID fuera distinto.
