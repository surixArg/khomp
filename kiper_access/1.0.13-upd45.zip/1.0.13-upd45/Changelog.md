# Kiper Access Veicular

### Version 1.0.13 Update 45

Compilation date: 2024/03/22
Commit: dbbaee1e3ac307a613768ad365986876e3033eea

---

### Changelog

* El comando update_cpu ahora usa SSL por defecto.

---
