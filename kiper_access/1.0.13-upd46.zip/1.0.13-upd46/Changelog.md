# Kiper Access Veicular

### Version 1.0.13 Update 46

Compilation date: 2024/03/26
Commit: 0d1fb54e26ff80a311f84dacf25941892c7ff8ff

---

### Changelog

* [Trello](https://trello.com/c/SAzq6MkY/474-access-veicular-updatecpu-ssl-por-default). El comando update_cpu ahora utiliza SSL por defecto.

---
