# Kiper Access Veicular

### Version 1.0.13 Update 47

Compilation date: 2024/03/27
Commit: 4980de0380836603c9b80b4c3eb8718786375774

---

### Changelog

* [Trello](https://trello.com/c/gDXC2EkT/475-access-veicular-par%C3%A2metro-na-lista-offline-est%C3%A1-como-interger-deveria-ser-boolean). El parámetro "allowed" pasa a ser booleano en los eventos offline.
* [Trello](https://trello.com/c/nULQItFu/276-access-veicular-feature-integra%C3%A7%C3%A3o-com-o-produto-veicular-ble). Se hacen mejoras de syslogs de BLE según lo solicitado en esta tarjeta. Los syslogs de BLE ahora muestran la MAC del dispositivo BLE.

---
