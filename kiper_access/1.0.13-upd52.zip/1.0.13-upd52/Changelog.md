# Kiper Access Veicular

### Version 1.0.13 Update 52

Compilation date: 2024/04/24
Commit: 637706865dbe21de6b829eebd585d599485d1571

---

### Changelog

* [Trello](https://trello.com/c/2hvb7g2H/479-access-veicular-bug-na-gera%C3%A7%C3%A3o-do-carpanic). Se soluciona un problema que generaba que se enviara Reason -10 luego de un evento car panic. Se adjunta video de demostración dentro del archivo .zip.

---
