# Kiper Access Veicular

### Version 1.0.13 Update 53

Compilation date: 2024/04/26
Commit: b0c70be545d5f07fa133389eb4f65f5e3adaab11

---

### Changelog

* Se soluciona un problema que generaba que, cuando button_enable estaba en true, al mantener presionado un botón se generaba un Reason -10 en lugar de car_panic.

---
