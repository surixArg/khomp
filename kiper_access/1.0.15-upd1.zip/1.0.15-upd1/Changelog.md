# Kiper Access Veicular

### Version 1.0.15 Update 1

Compilation date: 2024/06/03
Commit: 6176fd92f44c4112703a1ea25c6e71e14d0e7678

---

### Changelog

* [Trello](https://trello.com/c/x3n7j5qg/486-access-veicular-bugfix-parametro-de-tempo-de-debounce-na-interface-web-n%C3%A3o-funciona). El tiempo de debounce ahora puede cambiarse correctamente desde la web.
* [Trello](https://trello.com/c/ZfRH1XtV/487-access-veicular-bugfix-sendofflineeventlist-com-par%C3%A2metros-fora-do-padr%C3%A3o-do-protocolo). Los parámetros "allowed" y "reason" de los eventos offline, ahora se encuentran dentro de un solo parámetro "access".

---
