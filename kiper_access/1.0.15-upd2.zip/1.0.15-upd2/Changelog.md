# Kiper Access Veicular

### Version 1.0.15 Update 2

Compilation date: 2024/06/03
Commit: cdf7d1e6d2e6ad23f0445b6e38fffd4947bbdb40

---

### Changelog

* Se soluciona un problema que generaba un error al intentar comprar licencias si el usuario comenzaba con "cl_".

---
