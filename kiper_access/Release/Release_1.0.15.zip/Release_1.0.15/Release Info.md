# Kiper Access Veicular

### Release Version 1.0.15

Compilation Date: 2024/04/30

Commit Hash: df94a12331b02985cd21adee067c711b46777510

